NOTICE :

Pour lancer le jeu, double-cliquer sur le JAR “BOULDER_DASH” en prenant soin d’avoir dans le même dossier le dossier “res”. Le dossier “res” contient en effet toutes les ressources / images du jeu !

PREREQUIS : JAVA 8 !

README : 

To play with game, double click on “BOULDER_DASH”; “res” folder should be in the same folder as “BOULDER_DASH”.

YOU NEED : Java 8 !